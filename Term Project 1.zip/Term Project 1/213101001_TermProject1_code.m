%input at 270 degree (2.36 sec)
a = [0; 0];
c = [-199.10; 239.63];
b = [1.1;-95];
d = [-201.22; -10.36];
e = [-311.18;-13.3];
p = [-463.76; 178];
ab = b-a;
bd = d-b;
cd = d-c;
be = e-b;
w2 = 2;
%velocity
m1 = [cd -bd];
m2 = w2*ab;
m = inv(m1)*m2;
w4 = m(1,1);
w3 = m(2,1);
%acceleration
n1 = [-cd(2,1) bd(2,1); cd(1,1) -bd(1,1)];
n2 = w4^2 * cd - w2^2 * ab - w3^2 * bd;
n = inv(n1)*n2;
a4 = n(1,1);
a3 = n(2,1);
rp = (p-a);

%output
px = rp(1,1)
py = rp(2,1)
vex = -w2*ab(2,1) - w3*be(2,1)
vey = w2*ab(1,1) + w3*be(1,1)
aex = -w2^2 * ab(1,1)-w3^2 * be(1,1) - a3*be(2,1)
aey = -w2^2 * ab(2,1)-w3^2 * be(2,1) + a3*be(1,1)

